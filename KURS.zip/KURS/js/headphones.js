
        // Глобальная переменная для хранения товаров
        let headphonesProducts = [];

        // Загрузка товаров из XML
        async function loadProducts() {
            try {
                const response = await fetch('katproduct.xml');
                if (!response.ok) throw new Error('Ошибка загрузки XML');
                
                const text = await response.text();
                const xml = new DOMParser().parseFromString(text, "text/xml");
                const category = 'headphones'; // Категория для этой страницы
                
                // Получаем все товары нужной категории
                headphonesProducts = Array.from(xml.querySelectorAll('product'))
                    .filter(product => product.querySelector('category').textContent === category)
                    .map(product => ({
                        id: parseInt(product.querySelector('id').textContent),
                        title: product.querySelector('title').textContent,
                        description: product.querySelector('description')?.textContent || '',
                        price: parseInt(product.querySelector('price').textContent),
                        stock: parseInt(product.querySelector('stock').textContent),
                        image: product.querySelector('image').textContent,
                        specs: Array.from(product.querySelectorAll('spec')).map(spec => ({
                        name: spec.getAttribute('name'),
                        value: spec.textContent}))
                    }));
                
                renderProducts();
            } catch (error) {
                console.error('Ошибка загрузки товаров:', error);
                document.getElementById('products-container').innerHTML = 
                    '<p>Не удалось загрузить товары. Пожалуйста, попробуйте позже.</p>';
            }
        }

        // Отображение товаров на странице
        function renderProducts() {
            const productsContainer = document.getElementById('products-container');
            const cart = getCart();
            
            productsContainer.innerHTML = '';
            
            headphonesProducts.forEach(product => {
                const inCart = cart[product.id] ? cart[product.id].quantity : 0;
                const available = product.stock - inCart;
                const specsHTML = product.specs.map(spec => `<div class="product-spec"><strong>${spec.name}:</strong> ${spec.value}</div>`).join('');
                
                const productHTML = `
                    <div class="product-card" data-id="${product.id}">
                        <div class="product-img">
                            <img src="${product.image}" alt="${product.title}">
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">${product.title}</h3>
                            ${product.description ? `<p class="product-description">${product.description}</p>` : ''}
                            ${specsHTML}
                            <div class="product-price">${product.price.toLocaleString()} р.</div>
                            <div class="product-stock ${available <= 0 ? 'out-of-stock' : ''}">
                                ${available > 0 ? `В наличии: ${available} шт.` : 'Нет на складе'}
                            </div>
                            ${available > 0 ? 
                                `<button class="add-to-cart">В корзину</button>` : 
                                `<button class="add-to-cart btn-out-of-stock" disabled>Нет на складе</button>`}
                        </div>
                    </div>
                `;
                
                productsContainer.innerHTML += productHTML;
            });
            
            setupAddToCartButtons();
        }

        // Работа с корзиной
        function getCart() {
            return JSON.parse(localStorage.getItem('cart')) || {};
        }

        function saveCart(cart) {
            localStorage.setItem('cart', JSON.stringify(cart));
        }

        function updateCartCount() {
            const cart = getCart();
            let totalCount = 0;
            
            for (const id in cart) {
                totalCount += cart[id].quantity;
            }
            
            document.querySelectorAll('.cart-count').forEach(el => {
                el.textContent = totalCount;
            });
        }

        // Добавление товара в корзину
        function addToCart(productId) {
            const product = headphonesProducts.find(p => p.id === productId);
            if (!product) return;
            
            const cart = getCart();
            const inCart = cart[productId] ? cart[productId].quantity : 0;
            
            // Проверяем доступное количество
            if (inCart >= product.stock) {
                alert('Достигнуто максимальное количество товара на складе');
                return;
            }
            
            // Обновляем корзину
            cart[productId] = {
                id: productId,
                title: product.title,
                price: product.price,
                image: product.image,
                quantity: inCart + 1
            };
            
            saveCart(cart);
            updateCartCount();
            renderProducts(); 
            
            // Анимация добавления
            const addButton = document.querySelector(`.product-card[data-id="${productId}"] .add-to-cart`);
            if (addButton) {
                addButton.textContent = 'Добавлено!';
                addButton.style.backgroundColor = '#4CAF50';
                
                setTimeout(() => {
                    addButton.textContent = 'В корзину';
                    addButton.style.backgroundColor = '#1a1a1a';
                }, 1000);
            }
        }

        // Настройка кнопок "Добавить в корзину"
        function setupAddToCartButtons() {
            document.querySelectorAll('.add-to-cart:not([disabled])').forEach(btn => {
                btn.addEventListener('click', function() {
                    const productId = parseInt(this.closest('.product-card').dataset.id);
                    addToCart(productId);
                });
            });
        }

        // Мобильное меню
        const menuBtn = document.querySelector('.mobile-menu-btn');
        const nav = document.querySelector('nav');
        
        if (menuBtn && nav) {
            menuBtn.addEventListener('click', () => {
                nav.classList.toggle('active');
            });
        }

        // Обьявление
        document.addEventListener('DOMContentLoaded', () => {
            loadProducts();
            updateCartCount();
        });
    