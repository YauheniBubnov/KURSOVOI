// Глобальная переменная для хранения данных о товарах
let allProducts = [];

// Загружаем данные о товарах из XML
async function loadProducts() {
    try {
        const response = await fetch('katproduct.xml');
        const text = await response.text();
        const xml = new DOMParser().parseFromString(text, "text/xml");
        
        allProducts = Array.from(xml.querySelectorAll('product')).map(product => ({
            id: parseInt(product.querySelector('id').textContent),
            category: product.querySelector('category').textContent,
            title: product.querySelector('title').textContent,
            description: product.querySelector('description')?.textContent || '',
            price: parseInt(product.querySelector('price').textContent),
            stock: parseInt(product.querySelector('stock').textContent),
            image: product.querySelector('image').textContent
        }));
        
        return allProducts;
    } catch (error) {
        console.error('Ошибка загрузки товаров:', error);
        return [];
    }
}

// Обновляем страницу корзины
async function updateCartPage() {
    const cart = getCart();
    const cartItemsContainer = document.getElementById('cart-items-container');
    const emptyCartMessage = document.getElementById('empty-cart-message');
    
    if (Object.keys(cart).length === 0) {
        cartItemsContainer.innerHTML = '';
        emptyCartMessage.style.display = 'block';
        updateCartTotals(cart);
        return;
    }
    
    emptyCartMessage.style.display = 'none';
    
    // Загружаем товары
    if (allProducts.length === 0) {
        await loadProducts();
    }
    
    let cartItemsHTML = '';
    
    for (const id in cart) {
        const item = cart[id];
        // Ищем товар в списке или используем данные из корзины
        const product = allProducts.find(p => p.id === parseInt(id)) || {
            id: parseInt(id),
            title: item.title || 'Товар',
            price: item.price || 0,
            stock: item.stock || 99,
            image: item.image || 'images/ushi.jpg'
        };
        
        cartItemsHTML += `
            <div class="cart-item" data-id="${id}">
                <div class="cart-item-img">
                    <img src="${product.image}" alt="${product.title}">
                </div>
                <div class="cart-item-details">
                    <h3 class="cart-item-title">${product.title}</h3>
                    <div class="cart-item-price">${product.price.toLocaleString()} р.</div>
                    <div class="cart-item-stock">В наличии: ${product.stock} шт.</div>
                    <div class="cart-item-actions">
                        <div class="quantity-control">
                            <button class="quantity-btn minus">-</button>
                            <input type="number" value="${item.quantity}" min="1" max="${product.stock}" class="quantity-input">
                            <button class="quantity-btn plus">+</button>
                        </div>
                        <div class="remove-item">Удалить</div>
                    </div>
                </div>
            </div>
        `;
    }
    
    cartItemsContainer.innerHTML = cartItemsHTML;
    setupCartItemEvents();
    updateCartTotals(cart);
}

// Получаем текущую корзину из localStorage
function getCart() {
    return JSON.parse(localStorage.getItem('cart')) || {};
}

// Сохраняем корзину в localStorage
function saveCart(cart) {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// События в корзине
function setupCartItemEvents() {
    // Кнопки изменения количества
    document.querySelectorAll('.quantity-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const itemElement = this.closest('.cart-item');
            const id = itemElement.dataset.id;
            const input = itemElement.querySelector('.quantity-input');
            let quantity = parseInt(input.value);
            const product = allProducts.find(p => p.id === parseInt(id));
            
            if (this.classList.contains('minus') && quantity > 1) {
                quantity--;
            } else if (this.classList.contains('plus')) {
                // Проверяем, не превышает ли новое количество доступный запас
                if (product && quantity >= product.stock) {
                    alert(`Доступно только ${product.stock} шт. этого товара`);
                    return;
                }
                quantity++;
            }
            
            input.value = quantity;
            updateCartItem(id, quantity);
        });
    });
    
    // Изменение количества
    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', function() {
            const itemElement = this.closest('.cart-item');
            const id = itemElement.dataset.id;
            let quantity = parseInt(this.value);
            const product = allProducts.find(p => p.id === parseInt(id));
            
            if (isNaN(quantity)) quantity = 1;
            if (quantity < 1) quantity = 1;
            
            // Проверяем доступное количество
            if (product && quantity > product.stock) {
                quantity = product.stock;
                alert(`Доступно только ${product.stock} шт. этого товара`);
            }
            
            this.value = quantity;
            updateCartItem(id, quantity);
        });
    });
    
    // Кнопки удаления товара
    document.querySelectorAll('.remove-item').forEach(btn => {
        btn.addEventListener('click', function() {
            const itemElement = this.closest('.cart-item');
            const id = itemElement.dataset.id;
            
            itemElement.style.animation = 'fadeOut 0.3s ease';
            
            setTimeout(() => {
                removeCartItem(id);
            }, 300);
        });
    });
}

// Обновление товара в корзине
function updateCartItem(id, quantity) {
    let cart = getCart();
    
    if (cart[id]) {
        // Находим товар в allProducts
        const product = allProducts.find(p => p.id === parseInt(id));
        
        // Если товар найден и запрашиваемое количество больше чем в наличии
        if (product && quantity > product.stock) {
            quantity = product.stock; // Устанавливаем максимально доступное количество
        }
        
        cart[id].quantity = quantity;
        saveCart(cart);
        updateCartCount();
        updateCartTotals(cart);
    }
}

// Удаление товара из корзины
function removeCartItem(id) {
    let cart = getCart();
    
    if (cart[id]) {
        delete cart[id];
        saveCart(cart);
        updateCartCount();
        updateCartPage();
    }
}

// Обновление итоговой суммы
function updateCartTotals(cart) {
    let totalItems = 0;
    let subtotal = 0;
    
    for (const id in cart) {
        totalItems += cart[id].quantity;
        subtotal += cart[id].quantity * (cart[id].price || 0);
    }
    
    // Расчет скидки (10% при сумме > 100000-просто так)
    const discount = subtotal > 100000 ? Math.round(subtotal * 0.1) : 0;
    const total = subtotal - discount;
    
    document.getElementById('total-items').textContent = totalItems;
    document.getElementById('subtotal').textContent = subtotal.toLocaleString() + ' р.';
    document.getElementById('discount').textContent = discount > 0 ? `-${discount.toLocaleString()} р.` : '0 р.';
    document.getElementById('total').textContent = total.toLocaleString() + ' р.';
}

// Обновление счетчика корзины в шапке
function updateCartCount() {
    const cart = getCart();
    let totalCount = 0;
    
    for (const id in cart) {
        totalCount += cart[id].quantity;
    }
    
    document.querySelectorAll('.cart-count').forEach(el => {
        el.textContent = totalCount;
    });
}

// Оформление заказа
document.querySelector('.checkout-btn')?.addEventListener('click', function() {
    const cart = getCart();
    
    if (Object.keys(cart).length === 0) {
        alert('Ваша корзина пуста!');
        return;
    }
    
    alert('Заказ оформлен! Спасибо за покупку!');
    localStorage.removeItem('cart');
    updateCartCount();
    updateCartPage();
});

// Мобильное меню
const menuBtn = document.querySelector('.mobile-menu-btn');
const nav = document.querySelector('nav');
    
if (menuBtn && nav) {
    menuBtn.addEventListener('click', () => {
        nav.classList.toggle('active');
    });
}

// Добавляем стили
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeOut {
        from { opacity: 1; transform: translateY(0); }
        to { opacity: 0; transform: translateY(-20px); }
    }
`;
document.head.appendChild(style);

document.addEventListener('DOMContentLoaded', async () => {
    await updateCartPage();
    updateCartCount();
});